package com.lojaroupa.gui;

import com.lojaroupa.dao.ClienteDAO;
import com.lojaroupa.dao.PedidoDAO;
import com.lojaroupa.model.Cliente;
import com.lojaroupa.model.Pedido;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class AdminDashboardFrame extends JFrame {

    private static final long serialVersionUID = 1L;

    private JTable clientesTable;
    private DefaultTableModel clientesTableModel;
    private JTable pedidosTable;
    private DefaultTableModel pedidosTableModel;
    private JTabbedPane tabbedPane;

    public AdminDashboardFrame(int initialTabIndex) {
        setTitle("Admin Dashboard - Loja de Roupa");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Clientes", createClientesPanel());
        tabbedPane.addTab("Pedidos", createPedidosPanel());
        add(tabbedPane, BorderLayout.CENTER);

        if (initialTabIndex >= 0 && initialTabIndex < tabbedPane.getTabCount()) {
            tabbedPane.setSelectedIndex(initialTabIndex);
        }

      
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton backToMenuButton = new JButton("Voltar ao Menu"); 
        backToMenuButton.addActionListener(e -> {
            new AdminMenuFrame().setVisible(true);
            dispose(); 
        });
        bottomPanel.add(backToMenuButton);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    public AdminDashboardFrame() {
        this(0);
    }

    private JPanel createClientesPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        clientesTableModel = new DefaultTableModel(
                new Object[]{"ID", "Nome", "CPF", "Email", "Telefone", "Endereço", "CEP"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        clientesTable = new JTable(clientesTableModel);
        panel.add(new JScrollPane(clientesTable), BorderLayout.CENTER);

        JButton carregarBtn = new JButton("Carregar Clientes");
        carregarBtn.addActionListener(e -> carregarClientes());

        JButton novoBtn = new JButton("Novo Cliente");
        novoBtn.addActionListener(e -> abrirFormularioNovoCliente());

        JButton excluirClienteBtn = new JButton("Excluir Cliente Selecionado");
        excluirClienteBtn.addActionListener(e -> excluirClienteSelecionado());

        JPanel btnPanel = new JPanel();
        btnPanel.add(carregarBtn);
        btnPanel.add(novoBtn);
        btnPanel.add(excluirClienteBtn);
        panel.add(btnPanel, BorderLayout.SOUTH);

        carregarClientes();

        return panel;
    }

    private JPanel createPedidosPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        pedidosTableModel = new DefaultTableModel(
                new Object[]{"ID Pedido", "ID Cliente", "Data Pedido", "Status", "Valor Total"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        pedidosTable = new JTable(pedidosTableModel);
        panel.add(new JScrollPane(pedidosTable), BorderLayout.CENTER);

        JButton carregarBtn = new JButton("Carregar Pedidos");
        carregarBtn.addActionListener(e -> carregarPedidos());

        JButton liberarPedidoBtn = new JButton("Liberar Pedido Selecionado");
        liberarPedidoBtn.addActionListener(e -> liberarPedidoSelecionado());

        JPanel btnPanel = new JPanel();
        btnPanel.add(carregarBtn);
        btnPanel.add(liberarPedidoBtn);
        panel.add(btnPanel, BorderLayout.SOUTH);

        carregarPedidos();

        return panel;
    }

    private void carregarClientes() {
        ClienteDAO dao = new ClienteDAO();
        List<Cliente> list = dao.listarTodos();
        clientesTableModel.setRowCount(0);
        for (Cliente c : list) {
            clientesTableModel.addRow(new Object[]{
                    c.getIdCliente(),
                    c.getNome(),
                    c.getCpf(),
                    c.getEmail(),
                    c.getTelefone(),
                    c.getEndereco(),
                    c.getCep()
            });
        }
    }

    private void carregarPedidos() {
        PedidoDAO dao = new PedidoDAO();
        List<Pedido> list = dao.listarTodos();
        pedidosTableModel.setRowCount(0);
        for (Pedido p : list) {
            pedidosTableModel.addRow(new Object[]{
                    p.getIdPedido(),
                    p.getIdCliente(),
                    p.getDataPedido(),
                    p.getStatusPedido(),
                    p.getValorTotal()
            });
        }
    }

    private void abrirFormularioNovoCliente() {
        JTextField nomeField = new JTextField(20);
        JTextField cpfField = new JTextField(14);
        JTextField emailField = new JTextField(20);
        JTextField telefoneField = new JTextField(15);
        JTextField enderecoField = new JTextField(30);
        JTextField cepField = new JTextField(9);
        JPasswordField senhaField = new JPasswordField(20);

        JPanel form = new JPanel(new GridLayout(0, 2, 5, 5));
        form.add(new JLabel("Nome:"));    form.add(nomeField);
        form.add(new JLabel("CPF:"));     form.add(cpfField);
        form.add(new JLabel("Email:"));   form.add(emailField);
        form.add(new JLabel("Telefone:"));form.add(telefoneField);
        form.add(new JLabel("Endereço:"));form.add(enderecoField);
        form.add(new JLabel("CEP:"));     form.add(cepField);
        form.add(new JLabel("Senha:"));   form.add(senhaField);

        int result = JOptionPane.showConfirmDialog(
                this, form, "Novo Cliente", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            if (nomeField.getText().isEmpty() || emailField.getText().isEmpty() || new String(senhaField.getPassword()).isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nome, Email e Senha são campos obrigatórios.", "Erro de Cadastro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Cliente c = new Cliente();
            c.setNome(nomeField.getText());
            c.setCpf(cpfField.getText());
            c.setEmail(emailField.getText());
            c.setTelefone(telefoneField.getText());
            c.setEndereco(enderecoField.getText());
            c.setCep(cepField.getText());
            c.setSenha(new String(senhaField.getPassword()));
            c.setDataCadastro(LocalDate.now());

            try {
                new ClienteDAO().inserir(c);
                JOptionPane.showMessageDialog(this, "Cliente cadastrado com sucesso!", "Cadastro", JOptionPane.INFORMATION_MESSAGE);
                carregarClientes();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao cadastrar cliente: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        }
    }

    private void excluirClienteSelecionado() {
        int selectedRow = clientesTable.getSelectedRow();
        if (selectedRow >= 0) {
            int idCliente = (int) clientesTableModel.getValueAt(selectedRow, 0);
            int confirm = JOptionPane.showConfirmDialog(this,
                    "Tem certeza que deseja excluir o cliente com ID: " + idCliente + "?",
                    "Confirmar Exclusão", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                new ClienteDAO().deletar(idCliente);
                carregarClientes();
                JOptionPane.showMessageDialog(this, "Cliente excluído com sucesso!");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um cliente para excluir.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void liberarPedidoSelecionado() {
        int selectedRow = pedidosTable.getSelectedRow();
        if (selectedRow >= 0) {
            int idPedido = (int) pedidosTableModel.getValueAt(selectedRow, 0);
            String currentStatus = (String) pedidosTableModel.getValueAt(selectedRow, 3);

            if (currentStatus != null && (currentStatus.equals("Liberado") || currentStatus.equals("Entregue"))) {
                JOptionPane.showMessageDialog(this, "Pedido já está com status de 'Liberado' ou 'Entregue'.", "Aviso", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(this,
                    "Tem certeza que deseja LIBERAR (excluir) o pedido com ID: " + idPedido + "?\n" +
                    "Esta ação geralmente significa que o pedido foi processado e pode ser removido do painel.",
                    "Confirmar Liberação/Exclusão", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                new PedidoDAO().deletar(idPedido);
                carregarPedidos();
                JOptionPane.showMessageDialog(this, "Pedido liberado com sucesso!");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um pedido para liberar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }
}