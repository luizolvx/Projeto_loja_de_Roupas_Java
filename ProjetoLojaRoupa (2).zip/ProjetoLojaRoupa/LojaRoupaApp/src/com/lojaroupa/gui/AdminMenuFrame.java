package com.lojaroupa.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminMenuFrame extends JFrame {

    private static final long serialVersionUID = 1L; 

    public AdminMenuFrame() {
        setTitle("Menu do Administrador");
        setSize(350, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout()); 

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); 
        gbc.fill = GridBagConstraints.HORIZONTAL; 

        JButton gerenciarClientesBtn = new JButton("Gerenciar Clientes");
        gerenciarClientesBtn.setFont(new Font("Arial", Font.BOLD, 14));
        gerenciarClientesBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AdminDashboardFrame(0).setVisible(true); 
                dispose(); 
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(gerenciarClientesBtn, gbc);

        JButton gerenciarPedidosBtn = new JButton("Gerenciar Pedidos");
        gerenciarPedidosBtn.setFont(new Font("Arial", Font.BOLD, 14));
        gerenciarPedidosBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AdminDashboardFrame(1).setVisible(true);
                dispose(); 
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(gerenciarPedidosBtn, gbc);
    }
}