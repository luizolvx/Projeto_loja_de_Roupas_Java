package com.lojaroupa.gui;

import com.lojaroupa.dao.ClienteDAO;
import com.lojaroupa.model.Cliente;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate; // Para dataCadastro, se aplicável

public class ClientMenuFrame extends JFrame {

    private static final long serialVersionUID = 1L; 

    public ClientMenuFrame() {
        setTitle("Menu do Cliente");
        setSize(350, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout()); 

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); 
        gbc.fill = GridBagConstraints.HORIZONTAL; 

        JButton verProdutosBtn = new JButton("Ver Produtos");
        verProdutosBtn.setFont(new Font("Arial", Font.BOLD, 14));
        verProdutosBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ClientDashboardFrame().setVisible(true); 
                dispose(); 
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(verProdutosBtn, gbc);

        JButton cadastrarClienteBtn = new JButton("Cadastrar Novo Cliente");
        cadastrarClienteBtn.setFont(new Font("Arial", Font.BOLD, 14));
        cadastrarClienteBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirFormularioNovoCliente(); 
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(cadastrarClienteBtn, gbc);
    }

    private void abrirFormularioNovoCliente() {
        JTextField nomeField = new JTextField(20);
        JTextField cpfField = new JTextField(14);
        JTextField emailField = new JTextField(20);
        JTextField telefoneField = new JTextField(15);
        JTextField enderecoField = new JTextField(30);
        JTextField cepField = new JTextField(9);
        JPasswordField senhaField = new JPasswordField(20); 

        JPanel form = new JPanel(new GridLayout(0, 2, 5, 5)); 
        form.add(new JLabel("Nome:"));      form.add(nomeField);
        form.add(new JLabel("CPF:"));       form.add(cpfField);
        form.add(new JLabel("Email:"));     form.add(emailField);
        form.add(new JLabel("Telefone:"));  form.add(telefoneField);
        form.add(new JLabel("Endereço:"));  form.add(enderecoField);
        form.add(new JLabel("CEP:"));       form.add(cepField);
        form.add(new JLabel("Senha:"));     form.add(senhaField); 

        int result = JOptionPane.showConfirmDialog(
                this, form, "Cadastrar Novo Cliente", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        
        if (result == JOptionPane.OK_OPTION) {
           
            if (nomeField.getText().isEmpty() || emailField.getText().isEmpty() || new String(senhaField.getPassword()).isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nome, Email e Senha são campos obrigatórios.", "Erro de Cadastro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Cliente c = new Cliente();
            c.setNome(nomeField.getText());
            c.setCpf(cpfField.getText());
            c.setEmail(emailField.getText());
            c.setTelefone(telefoneField.getText());
            c.setEndereco(enderecoField.getText());
            c.setCep(cepField.getText());
            c.setSenha(new String(senhaField.getPassword())); 
            c.setDataCadastro(LocalDate.now()); 

            try {
                new ClienteDAO().inserir(c);
                JOptionPane.showMessageDialog(this, "Cliente cadastrado com sucesso!", "Cadastro", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao cadastrar cliente: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        }
    }
}