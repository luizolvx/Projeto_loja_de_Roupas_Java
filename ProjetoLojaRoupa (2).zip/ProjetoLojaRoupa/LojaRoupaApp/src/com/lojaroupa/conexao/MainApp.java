package com.lojaroupa.conexao;

import javax.swing.SwingUtilities;
import com.lojaroupa.gui.LoginFrame;

public class MainApp {
    public static void main(String[] args) {
        
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                
                new LoginFrame().setVisible(true);
            }
        });
    }
}
